const ensureAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
        return next();
    }
    req.flash('error_msg', 'Please log in to view that resource');
    res.redirect('/auth/login');
};

const isAdmin = (req, res, next) => {
    if (req.isAuthenticated() && req.user.role === 'admin') {
        return next();
    }
    // Redirect non-admin users
    req.flash('error_msg', 'You do not have permission to view that page');
    res.redirect('/user/dashboard'); // Redirect to a general dashboard or login page
};

module.exports = { ensureAuthenticated, isAdmin };
