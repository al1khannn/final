const axios = require('axios');
require('dotenv').config();

const fetchCityData = async (cityName) => {
    const options = {
        method: 'GET',
        url: 'https://api.api-ninjas.com/v1/city',
        params: {
            name: cityName
        },
        headers: {
            'X-Api-Key': process.env.API_NINJAS_KEY
        }
    };

    try {
        const response = await axios.request(options);
        return response.data;
    } catch (error) {
        console.error('Error fetching city data:', error);
        return null;
    }
};

module.exports = { fetchCityData };
