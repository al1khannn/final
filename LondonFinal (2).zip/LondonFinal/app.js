// Import necessary modules
require('dotenv').config(); // Load environment variables
const express = require('express');
const mongoose = require('mongoose');
const nodemailer = require('nodemailer');
const session = require('express-session');
const passport = require('passport');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const path = require('path');
const connectDB = require('./config/db');
const flash = require('connect-flash');
const User = require('./models/User');
const cityRoutes = require('./routes/cityRoutes');
const nationalityRoutes = require('./routes/nationalityRoutes');


// Import routes
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const adminRoutes = require('./routes/adminRoutes');

// Passport config
require('./utils/passportConfig')(passport);

// Connect to Database

connectDB();

async function createOrUpdateAdminUser() {
  const email = "bondliam76@gmail.com";
  const password = "12345678"; // This should be securely hashed
  const hashedPassword = await bcrypt.hash(password, 10);

  const adminUser = await User.findOneAndUpdate(
      { email: email },
      {
          email: email,
          password: hashedPassword,
          role: 'admin', // Set the user's role to 'admin'
          // include other necessary fields as per your schema, or set defaults
      },
      { new: true, upsert: true, setDefaultsOnInsert: true }
  );

  console.log("Admin user created or updated:", adminUser);
}

createOrUpdateAdminUser().catch(console.error);

function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
      return next();
  }
  // Redirect to login page if the user is not authenticated
  req.flash('error_msg', 'Please log in to view that resource');
  res.redirect('/auth/login');
}

const app = express();

// EJS setup
app.set('view engine', 'ejs');


// BodyParser Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Express session middleware
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: true,
  saveUninitialized: true,
}));

app.use(flash());

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Set static folder
app.use(express.static(path.join(__dirname, 'public')));

// Use Routes
app.use('/auth', authRoutes);
app.use('/user', userRoutes);
app.use('/admin', adminRoutes);

app.use('/', cityRoutes);
app.use('/', nationalityRoutes);
// Index route
app.get('/', (req, res) => res.redirect('/auth/login'));

app.get('/profile', ensureAuthenticated, (req, res) => {
  res.render('profile', { user: req.user });
});

// Catch-all for 404 errors
app.use((req, res, next) => {
  res.status(404).send("Sorry can't find that!");
});

// Set the port
const PORT = process.env.PORT || 3000;

// Start the server
app.listen(PORT, console.log(`Server started on port ${PORT}`));
