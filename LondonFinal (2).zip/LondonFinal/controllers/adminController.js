const Item = require('../models/Item');

const adminController = {
    // Display list of all items
    listItems: async (req, res) => {
        try {
            const items = await Item.find();
            res.render('admin/itemsList', { items }); // Ensure you have this view
        } catch (err) {
            console.error(err);
            res.redirect('/admin');
        }
    },

    // Display the form for adding a new item
    showAddItemForm: (req, res) => {
        res.render('admin/addItem'); // Ensure you have this view
    },

    // Handle adding a new item
    addItem: async (req, res) => {
        const { name, description, image } = req.body; // Now expecting a single image
        try {
            const newItem = new Item({ name, description, image }); // Pass the single image URL
            await newItem.save();
            res.redirect('/admin/items');
        } catch (err) {
            console.error(err);
            res.render('admin/addItem', { error: 'Error creating item' });
        }
    },
    // Display the form for editing an item
    showEditItemForm: async (req, res) => {
        try {
            const item = await Item.findById(req.params.id);
            res.render('admin/editItem', { item });
        } catch (err) {
            console.error(err);
            res.redirect('/admin/items');
        }
    },

    // Handle updating an item
    updateItem: async (req, res) => {
        const { name, description, image } = req.body;
        try {
            await Item.findByIdAndUpdate(req.params.id, { name, description, image });
            res.redirect('/admin/items');
        } catch (err) {
            console.error(err);
            res.render('admin/editItem', { 
                item: req.body,
                error: 'Error updating item'
            });
        }
    },
    

    // Handle deleting an item
    deleteItem: async (req, res) => {
        try {
            await Item.findByIdAndRemove(req.params.id);
            res.redirect('/admin/items');
        } catch (err) {
            console.error(err);
            res.redirect('/admin/items');
        }
    }
};

module.exports = adminController;
