const User = require('../models/User');
const bcrypt = require('bcryptjs');
const passport = require('passport');
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail', // For Gmail, 'gmail' is predefined, otherwise specify SMTP settings
    auth: {
        user: 'bondliam76@gmail.com', // Your email
        pass: 'fdiz mszv mfjh dfxm' // Your email password or App Password if 2FA is enabled
    }
});

const authController = {
    // Registration Logic
    registerUser: async (req, res) => {
        const { username, email, password, firstName, lastName, age, country, gender } = req.body;
        try {
            let user = await User.findOne({ email: email });
            if (user) {
                req.flash('error_msg', 'Email already exists');
                return res.redirect('/auth/register');
            }

            user = new User({
                username,
                email,
                password, // This will be hashed below
                firstName,
                lastName,
                age,
                country,
                gender,
                createdAt: new Date()
            });

            // Hash password
            bcrypt.genSalt(10, (err, salt) => {
                bcrypt.hash(user.password, salt, async (err, hash) => {
                    if (err) throw err;
                    user.password = hash;
                    await user.save();

                    // Send a confirmation email
                    const mailOptions = {
                        from: 'bondliam76@gmail.com', // Sender address
                        to: email, // List of receivers
                        subject: 'Registration Successful', // Subject line
                        text: `Hi ${firstName}, welcome to our app! Your registration is successful.` // Plain text body
                    };

                    transporter.sendMail(mailOptions, (err, info) => {
                        if(err) {
                            console.error('Error sending email:', err);
                        } else {
                            console.log('Email sent:', info.response);
                        }
                    });

                    req.flash('success_msg', 'You are now registered and can log in');
                    res.redirect('/auth/login');
                });
            });
        } catch (err) {
            console.error(err);
            req.flash('error_msg', 'An error occurred, please try again');
            res.redirect('/auth/register');
        }
    },

    // Login Logic
    loginUser: (req, res, next) => {
        passport.authenticate('local', {
            successRedirect: '/user/dashboard', // Corrected path
            failureRedirect: '/auth/login',
            failureFlash: true
        })(req, res, next);
    },

    // Logout Logic
    logoutUser: (req, res) => {
        req.logout(() => {
            req.flash('success_msg', 'You are logged out');
            res.redirect('/auth/login');
        });
    }
};

module.exports = authController;
