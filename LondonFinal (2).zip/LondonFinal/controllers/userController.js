const User = require('../models/User');
const Item = require('../models/Item'); // Adjust the path as necessary

const bcrypt = require('bcryptjs');

const userController = {
    // Display the user's dashboard
    viewDashboard: async (req, res) => {
        try {
            const items = await Item.find(); // Fetch all items
            res.render('dashboard', { user: req.user, items: items });
        } catch (err) {
            console.error(err);
            req.flash('error_msg', 'Error fetching items');
            res.redirect('/');
        }
    },

    // Display the profile update form
    viewProfileUpdate: (req, res) => {
        res.render('updateProfile', { user: req.user });
    },

    // Handle profile updates
    updateProfile: async (req, res) => {
        const { username, email, password } = req.body;
        try {
            const userId = req.user._id;
            const updatedData = { username, email };

            // If the password field is not empty, hash the new password
            if (password) {
                const salt = await bcrypt.genSalt(10);
                const hashedPassword = await bcrypt.hash(password, salt);
                updatedData.password = hashedPassword;
            }

            await User.findByIdAndUpdate(userId, updatedData, { new: true });
            req.flash('success_msg', 'Profile updated successfully');
            res.redirect('/user/dashboard');
        } catch (err) {
            console.error(err);
            req.flash('error_msg', 'Error updating profile');
            res.redirect('/user/updateProfile');
        }
    }
};

module.exports = userController;
