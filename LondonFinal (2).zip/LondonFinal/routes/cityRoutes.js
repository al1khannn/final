const express = require('express');
const router = express.Router();
const { fetchCityData } = require('../utils/apiIntegrations');

router.get('/city-data', async (req, res) => {
    let cityData = null;
    const { cityName } = req.query; // Assume the query parameter is named 'cityName'

    if (cityName) {
        cityData = await fetchCityData(cityName);
    }

    res.render('city-data', { cityData }); // Assuming you have a 'city-data.ejs' template
});

module.exports = router;
