const express = require('express');
const router = express.Router();
const passport = require('passport');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const authController = require('../controllers/authController'); // Import the authController

// Registration Page
router.get('/register', (req, res) => {
    res.render('register');
});

// Registration Handling - Use authController's method
router.post('/register', authController.registerUser);

// Login Page
router.get('/login', (req, res) => {
    res.render('login');
});

// Login Handling - Updated to use authController's loginUser method
router.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return next(err);
        }
        if (!user) {
            // Handle login failure
            return res.redirect('/auth/login');
        }
        req.logIn(user, function(err) {
            if (err) {
                return next(err);
            }
            // Redirect based on role
            if (user.role === 'admin') {
                return res.redirect('/admin/items'); // Adjust as necessary
            } else {
                return res.redirect('/user/dashboard'); // Adjust as necessary
            }
        });
    })(req, res, next);
});

// Logout Handling - Updated to use authController's logoutUser method
router.get('/logout', authController.logoutUser);

module.exports = router;
