const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { ensureAuthenticated, isAdmin } = require('../config/auth');

router.get('/items', [ensureAuthenticated, isAdmin], adminController.listItems);
router.get('/items/add', [ensureAuthenticated, isAdmin], adminController.showAddItemForm);
router.post('/items/add', [ensureAuthenticated, isAdmin], adminController.addItem);
router.get('/items/edit/:id', [ensureAuthenticated, isAdmin], adminController.showEditItemForm);
router.post('/items/edit/:id', [ensureAuthenticated, isAdmin], adminController.updateItem);
router.get('/items/delete/:id', [ensureAuthenticated, isAdmin], adminController.deleteItem);

module.exports = router;
