const express = require('express');
const axios = require('axios');
const router = express.Router();

router.get('/predict-nationality', (req, res) => {
    // Provide default values for 'name' and 'result' when rendering the page initially
    res.render('predict-nationality', { name: '', result: null });
});
router.post('/predict-nationality', async (req, res) => {
    const { name } = req.body;
    try {
        const response = await axios.get(`https://api.nationalize.io/?name=${name}`);
        res.render('nationality-result', { name: name, result: response.data });
    } catch (error) {
        console.error('Error fetching nationality data:', error);
        res.send('Error fetching nationality data');
    }
});

module.exports = router;
