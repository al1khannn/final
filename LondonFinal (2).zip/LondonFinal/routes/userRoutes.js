const express = require('express');
const router = express.Router();
const { ensureAuthenticated } = require('../config/auth');
const userController = require('../controllers/userController');

// Route to display the dashboard
router.get('/dashboard', ensureAuthenticated, userController.viewDashboard);

// Route to display the profile update form
router.get('/updateProfile', ensureAuthenticated, userController.viewProfileUpdate);

// Route to handle profile update submissions
router.post('/updateProfile', ensureAuthenticated, userController.updateProfile);

module.exports = router;
